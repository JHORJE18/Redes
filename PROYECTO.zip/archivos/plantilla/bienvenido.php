<h1>Hola, Bienvenido</h1>
<hr>
<p>Esta es una plataforma montada desde cero a código usando una combinación entre PHP, Html y MySQL, para la realización del proyecto de Base de Datos en Florida Universitaria.
    
</p>
<br>
<img src="https://media.giphy.com/media/1C8bHHJturSx2/giphy.gif" style="width: 100%; height: 100%" align="center">
<br>

<p>La plataforma no es perfecta y puedes encontrarte con más de 18 BUG's, asi que me gustaria que todas las surgerencias y errores que encuentres, reportalos en la categoria de Reportes.
</p>