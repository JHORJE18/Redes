<?php 
$BASE = "REDES00"; 
$conexion = new mysqli("localhost", "root", "", "REDES00"); 
?>